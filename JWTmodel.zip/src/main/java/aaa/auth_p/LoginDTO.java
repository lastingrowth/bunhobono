package aaa.auth_p;

import lombok.Data;

@Data
public class LoginDTO {
    private String loginId, loginPwd;

}