package aaa.auth_p;

public class AuthController {

    @PostMapping("/login")
    public Object login(@RequestBody LoginDTO dto) {

        MemberDTO member = memberMapper.login(dto);

        String token = jwtUtil.createToken(
                member.getMemberNo(),
                member.getLoginId(),
                member.getRole()
        );

        return Map.of(
                "token", token,
                "loginId", member.getLoginId(),
                "role", member.getRole()
        );
    }
}
