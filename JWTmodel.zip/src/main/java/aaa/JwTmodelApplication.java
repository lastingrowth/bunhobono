package aaa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwTmodelApplication {

	public static void main(String[] args) {
		SpringApplication.run(JwTmodelApplication.class, args);
	}

}
