package aaa.jwt;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;


@Configuration
public class JwtConfig {

    private final JwtUtil jwtUtil;

    // 생성자 매개변수 JwtUtil jwtUtil 은 생성된 Bean 자동 호출
    public JwtConfig(JwtUtil jwtUtil){
        this.jwtUtil = jwtUtil;
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http){

        http.csrf(csrf->csrf.disable())
                //CORS 정책 활성화
                .cors(cors->{})
                // 인증없이 접근 허용할 경로
                .authorizeHttpRequests(auth->
                        // gall 모든 단계 허용 /**
                        auth
                                .requestMatchers(HttpMethod.OPTIONS,"/**").permitAll()
                                .requestMatchers("/main","/login","/gall/**").permitAll()

                                // 그 외 모든 요청은 인증 필요
                                .anyRequest().authenticated()
                );

        // JWT 필터 등록  <-- JWT 검사
        http.addFilterBefore(new JwtFilter(jwtUtil),
                UsernamePasswordAuthenticationFilter.class);


        return  http.build();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource(){

        // CORS 허용 규칙을 저장하는 객체 생성
        CorsConfiguration corsConfiguration = new CorsConfiguration();
        // 이 Vue 개발 서버에서 오는 요청만 허용
//        corsConfiguration.addAllowedOrigin("http://192.168.219.153:5173"); //mbc ip 주소
        corsConfiguration.addAllowedOrigin("http://192.168.219.153:5173");  // 집 ip 주소

        // GET, POST, PUT, DELETE, OPTIONS 등 모든 HTTP 메서드 허용
        corsConfiguration.addAllowedMethod("*");
        // Content-Type, Authorization 등 모든 요청 헤더 허용
        corsConfiguration.addAllowedHeader("*");
        //인증정보 : 쿠키,Authorization 허용
        corsConfiguration.setAllowCredentials(true);

        //URL 패턴과 매핑,  URL별로 CORS 규칙을 등록하는 객체 생성
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();

        //매핑에 대한 위의 CORS 청책허용,   서버의 모든 URL에 위 CORS 규칙 적용
        source.registerCorsConfiguration("/**", corsConfiguration);

        // 완성된 CORS 설정 반환
        return source;
    }

}
